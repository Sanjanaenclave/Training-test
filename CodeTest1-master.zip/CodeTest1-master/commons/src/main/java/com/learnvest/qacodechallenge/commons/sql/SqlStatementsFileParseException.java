package com.learnvest.qacodechallenge.commons.sql;

public class SqlStatementsFileParseException extends Exception {

    private static final long serialVersionUID = -1109510359149344775L;

    public SqlStatementsFileParseException(String string) {
        super(string);
    }

}
