package Trainingjava;

abstract class Assignment {

	//abstract method
	abstract void fun();
	abstract void test();
	
	// regular method
	void swapnonabstract()
	{
		System.out.println("non abstract method");
	}
	
	
}
	
class Childabstract extends Assignment{
	void fun()
	{
		System.out.println("abstract method printed");
	}
	void test()
	{
		
	}
}

public class AssignmentAbstract{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Assignment aa = new Childabstract();
		aa.fun();
		aa.swapnonabstract();
	}
	}

