package Trainingjava;

public class Student {

	public int studentId;
	public String name;
	public float qualifyingExamMarks;
	public static char residentialStatus;
	public int yearOfEngg;
	public String res1 = "Hostellers";
	public String res2 = "Day schoalrs";
	public String resstatus;
	
	public int getStudentId()
	{
		return studentId;
	}
	public String getName()
	{
		return name;
	}
	public float getQualifyingExamMarks()
	{
		return qualifyingExamMarks;
	}
	public char getResidentialStatus()
	{
		
		if(residentialStatus == 'H')
			System.out.println("Hostellers");
		else if(residentialStatus == 'D')
			System.out.println("Dayscholars");
		
		return residentialStatus;
	}
	public int getYearOfEngg()
	{
		return yearOfEngg;
	}
	
	public void setStudentId(int studid)
	{
		 studentId = studid;
	}
	public void setName(String studname)
	{
		 name = studname;
	}
	public void setQualifyingExamMarks(float studqualifyingExamMarks)
	{
		 qualifyingExamMarks = studqualifyingExamMarks;
	}
	public void setResidentialStatus(char studresidentialStatus)
	{
		
		residentialStatus = studresidentialStatus;
	}
	public void setYearOfEngg(int studyearOfEngg)
	{
		 yearOfEngg = studyearOfEngg;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Create object of Student class
		Student stud = new Student();
		
		
		//stud.setStudentId(1001);
		//stud.setName("Jacob");
		//stud.setQualifyingExamMarks(80);
		//stud.setResidentialStatus('H');
		//stud.setYearOfEngg(3);


		stud.setStudentId(1001);
		stud.setName("Jacob");
		stud.setQualifyingExamMarks(80);
		stud.setResidentialStatus('D');
		stud.setYearOfEngg(3);
		
		System.out.println(stud.getStudentId());
		System.out.println(stud.getName());
		System.out.println(stud.getQualifyingExamMarks());
		stud.getResidentialStatus();
		System.out.println(stud.getYearOfEngg());
		
	}

}
