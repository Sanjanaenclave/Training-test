package Trainingjava;

public class CalculatewithOperators {
   
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int res = 1 + 2;
		System.out.println(res);
		res -= 1;
		System.out.println(res);
		res *=2;
		System.out.println(res);
		res /= 2;
		System.out.println(res);
		res += 8;
		System.out.println(res);
		res %= 7;
		System.out.println(res);
		
		
	}

}
