package Trainingjava;

public class PerimeterCalcualtor extends Rectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle pc = new Rectangle();
		//PerimeterCalcualtor pc = new PerimeterCalcualtor();
		pc.setLength(40);
		pc.setBreadth(20);
		pc.calculatePerimeter();
	}

}
