package Trainingjava;

public class Account {

	private double balance = 1000.0;
	
	public double getBalance(int accid)
	{
		
	 
		  return balance;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account acc = new Account();
		System.out.println("Value is"+ acc.getBalance(123));
		

	}

}
