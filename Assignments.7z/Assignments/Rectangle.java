package Trainingjava;

public class Rectangle {

	private int length;
	private int breadth;
	public int area;
	
	public void setLength(int alength)
	{
		this.length = alength;
		
	}
	
	public int getLength()
	{
		return length;
		
	}
	public void setBreadth(int abreadth)
	{
		
		this.breadth = abreadth;
	}
	
	public int getbreadth()
	{
		return breadth;
		
	}
	
	public void calculatePerimeter()
	{
		area = 2*(length+breadth);
		System.out.println("Area of rectangle is:" +area);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Rectangle rec = new Rectangle();
		rec.setLength(50);
		rec.setBreadth(30);
		System.out.println(rec.length);
		System.out.println(rec.breadth);
		rec.calculatePerimeter();
	}

}
