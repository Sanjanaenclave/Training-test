package Trainingjava;
import java.util.*;

public class AssignmentListsort {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> ll = new ArrayList<Integer>();
		ll.add(0, 20);
		ll.add(1, 10);
		ll.add(2, 30);
		ll.add(3, 5);
		
		for(int i=0;i<ll.size();i++)
		{
			System.out.println(ll.get(i));
		}
		Collections.sort(ll);
		System.out.println("after sorting: ");
		for(int i=0;i<ll.size();i++)
		{
			System.out.println(ll.get(i));
		}
		
//		Collections.sort(ll, Collections.reverseOrder());
//		System.out.println("after sorting in descending order: ");
//		for(int i=0;i<ll.size();i++)
//		{
//			System.out.println(ll.get(i));
//		}
	}

}
